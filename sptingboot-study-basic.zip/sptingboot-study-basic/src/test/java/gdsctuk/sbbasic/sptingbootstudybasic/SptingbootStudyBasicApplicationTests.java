package gdsctuk.sbbasic.sptingbootstudybasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SptingbootStudyBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
