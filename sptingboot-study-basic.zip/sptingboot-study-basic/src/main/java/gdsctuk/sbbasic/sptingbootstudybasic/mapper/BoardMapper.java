package gdsctuk.sbbasic.sptingbootstudybasic.mapper;


import gdsctuk.sbbasic.sptingbootstudybasic.dto.BoardRequestDto;
import gdsctuk.sbbasic.sptingbootstudybasic.dto.BoardResponseDto;
import gdsctuk.sbbasic.sptingbootstudybasic.entity.Board;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class BoardMapper {

    public Board toEntity(BoardRequestDto request) {
        return Board.builder()
                .boardTitle(request.getBoardTitle())
                .boardContent(request.getBoardContent())
                .build();
    }

    public BoardResponseDto toResponse(Board board) {
        return BoardResponseDto.builder()
                .boardId(board.getBoardId())
                .boardTitle(board.getBoardTitle())
                .boardContent(board.getBoardContent())
                .build();
    }

    public BoardResponseDto toListResponse(List<Board> boardList) {
        List<BoardResponseDto> boardResponseList =
                boardList.stream().map(this::toResponse).collect(Collectors.toList());
        return BoardResponseDto.builder()
                .boardList(boardResponseList)
                .build();
    }
}