package gdsctuk.sbbasic.sptingbootstudybasic.controller;

import gdsctuk.sbbasic.sptingbootstudybasic.dto.BoardRequestDto;
import gdsctuk.sbbasic.sptingbootstudybasic.dto.BoardResponseDto;
import gdsctuk.sbbasic.sptingbootstudybasic.entity.Board;
import gdsctuk.sbbasic.sptingbootstudybasic.service.BoardService;
import lombok.RequiredArgsConstructor;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/boards")
public class BoardController {

    private final BoardService boardService;

    @Transactional
    @PostMapping("/create")
    public Long createBoard(BoardRequestDto request) {
        return boardService.saveBoard();
    }

    @GetMapping("/findAll")
    public List<BoardResponseDto> findALl() {
        return boardService.all();
    }

    @GetMapping("/find/{id}")
    public BoardResponseDto findById(@PathVariable Long id) {
        return boardService.findById(id);
    }

    @Transactional
    @PutMapping("/update/{id}")
    public Long updateBoard(@PathVariable Long id, @RequestBody BoardRequestDto request) {
        return boardService.updateBoard(id, request);
    }

    @Transactional
    @DeleteMapping("/delete/{id}")
    public Long deleteBoard(@PathVariable Long id) {
        return boardService.delete(id);
    }
}