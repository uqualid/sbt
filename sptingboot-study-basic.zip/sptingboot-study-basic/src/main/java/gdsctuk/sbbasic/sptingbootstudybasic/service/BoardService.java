package gdsctuk.sbbasic.sptingbootstudybasic.service;

import gdsctuk.sbbasic.sptingbootstudybasic.dto.BoardRequestDto;
import gdsctuk.sbbasic.sptingbootstudybasic.dto.BoardResponseDto;
import gdsctuk.sbbasic.sptingbootstudybasic.entity.Board;
import gdsctuk.sbbasic.sptingbootstudybasic.mapper.BoardMapper;
import gdsctuk.sbbasic.sptingbootstudybasic.repository.BoardRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;
import java.util.Optional;

import static org.hibernate.internal.util.collections.ArrayHelper.forEach;


@Service
@RequiredArgsConstructor
public class BoardService {
    private BoardRepository boardRepository;
    private final BoardMapper boardMapper;

    // 게시글 List 조회
    public List<Board> findAll() {
        return boardRepository.findAll();
    }

    // 게시글 하나 조회
    public Optional<Board> findOne(Long id) {
        return boardRepository.findById(id);
    }

    // 게시글 삭제
    @Transactional
    public void deleteBoard(Long id) {
        Board board = boardRepository.findById(id)
                .orElseThrow(IllegalStateException::new);
        board.delete();


    }

    public Board saveBoard(Board board) {
        return boardRepository.save(board);
    }


    public Board createBoard(BoardRequestDto request) {
        Board board = new Board();
        return  boardRepository.save(board);
    }


    // 게시글 업데이트
    public Board updateBoard(Long id, Board updatedBoard) {
        Optional<Board> optionalBoard = boardRepository.findById(id);
        if (optionalBoard.isPresent()) {
            Board board = optionalBoard.get();
            board.setBoardTitle(updatedBoard.getBoardTitle());
            board.setBoardContent(updatedBoard.getBoardContent());


            return boardRepository.save(board);
        } else {  // 게시글이 존재 x
            return null;
        }
    }



}
